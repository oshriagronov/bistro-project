package service;

public interface MessageSender {
    String send(String contact, String message);
}

