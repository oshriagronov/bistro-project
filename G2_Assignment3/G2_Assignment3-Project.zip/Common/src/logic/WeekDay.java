package logic;

/** Enumerates the days of the week used for scheduling. */
public enum WeekDay {
    Sunday,
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday
}
