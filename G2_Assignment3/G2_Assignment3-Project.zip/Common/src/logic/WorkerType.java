package logic;

/** Defines the roles a Bistro worker can hold. */
public enum WorkerType {
    MANAGER,
    EMPLOYEE
}
