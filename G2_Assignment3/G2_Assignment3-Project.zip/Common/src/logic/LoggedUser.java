package logic;

/**
 * Holds information about the currently logged-in user. This class is static so
 * the data is accessible from any screen.
 */
public class LoggedUser {

	private static int id;
	private static UserType type;

	public LoggedUser(int id, UserType type) {
		LoggedUser.id = id;
		LoggedUser.type = type;
	}

	public static int getId() {
		return id;
	}

	public static UserType getType() {
		return type;
	}

	public static void setId(int id) {
		LoggedUser.id = id;
	}

	public static void setSubscriber(int id) {
		LoggedUser.id = id;
		LoggedUser.type = UserType.SUBSCRIBER;
	}

	public static void setWorker(int id) {
		LoggedUser.id = id;
		LoggedUser.type = UserType.EMPLOYEE;
	}

	public static void setGuest() {
		LoggedUser.id = -1;
		LoggedUser.type = UserType.GUEST;
	}

	public static void setManager(int id) {
		LoggedUser.id = id;
		LoggedUser.type = UserType.MANAGER;
	}
}
