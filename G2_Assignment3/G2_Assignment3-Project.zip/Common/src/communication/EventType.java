package communication;

/** Events published within the client application. */
public enum EventType {
	ORDER_CHANGED,
    TABLE_CHANGED,
    WAITLIST_CHANGED,
    SCHEDULE_CHANGED
}
